from operator import itemgetter
from hashlib import md5
import os
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'utf-8')#유니코드 패치
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'utf-8')#유니코드 패치


TARGET_DIR   = 'C:\\Users\\CDH\\Desktop\\test'
LIMITED_SIZE = 1*(1024) # 1kb 용량 ( 괄호 안에 1024를 더 곱하면 단위가 MB로 바꿀 수 있음)


def md5sum(filename, buf_size=4068):
    m = md5()
    with open(filename, 'rb') as f:
        data = f.read(buf_size)
        while data:
            m.update(data)
            data = f.read(buf_size)
    return m.hexdigest()


def main():
    hash_cnt  = {}
    file_list = []
    for p, ds, fs in os.walk(TARGET_DIR):
        for f in fs:
            filename = os.path.join(p, f)
            if not os.path.isfile(filename) : continue
            if os.path.islink(filename) : continue
            if os.path.getsize(filename) < LIMITED_SIZE: continue
            crc = md5sum(filename)
            if crc in hash_cnt:
                hash_cnt[crc] = hash_cnt[crc] + 1
            else:
                hash_cnt[crc] = 1
            file_list.append(crc+"|"+filename)

    for hash, cnt in sorted(hash_cnt.items(), key=itemgetter(1), reverse=True):
        if cnt < 2: continue
        print("\n["+hash+"]")
        for item in file_list:
            (hash2, filename) = item.split("|")
            if hash == hash2 : print(filename)


if __name__ == '__main__':
    main()